<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "booking_db1";
	$tablename = "bookingcalendar";

	// translate these
	$months = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
	$headings = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
?>