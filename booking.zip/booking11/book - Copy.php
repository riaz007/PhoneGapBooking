<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Make booking</title>
</head>

<body>

<?php
// Captcha

	
	if(empty($errors))
	{
		include 'config.php';
		
		// Create connection
		$conn = mysqli_connect($servername, $username, $password,  $dbname);
		
		// Check connection
		if (!$conn) {
			die("Connection failed: " . mysqli_connect_error());
		}
		
		$start_day = intval(strtotime(htmlspecialchars($_POST["start_day"])));
		$start_time = (60*60*intval(htmlspecialchars($_POST["start_hour"]))) + (60*intval(htmlspecialchars($_POST["start_minute"])));
		$end_day = intval(strtotime(htmlspecialchars($_POST["end_day"])));
		$end_time = (60*60*intval(htmlspecialchars($_POST["end_hour"]))) + (60*intval(htmlspecialchars($_POST["end_minute"])));
		$name = htmlspecialchars($_POST["name"]);
		$phone = htmlspecialchars($_POST["phone"]);
		$item = htmlspecialchars($_POST["item"]);
		
		//echo $_POST["start_day"].'T'.$_POST["start_hour"];
		//exit();
		 $orgDate = $_POST["start_day"];  
         $newDate = date("Ymd", strtotime($orgDate));  
		 $startdatetime= $newDate.'T'.$_POST["start_hour"].'0000';
		 
		 $orgDate1 = $_POST["end_day"];  
         $newDate1 = date("Ymd", strtotime($orgDate1));  
		 $enddatetime= $newDate1.'T'.$_POST["end_hour"].'0000';
		
		$start_epoch = $start_day + $start_time;
		$end_epoch = $end_day + $end_time;
			$user_id = $_SESSION['id'];	
		// prevent double booking
		$sql = "SELECT * FROM $tablename WHERE item='$item' AND (start_day>=$start_day OR end_day>=$start_day) AND canceled=0";
		$result = mysqli_query($conn, $sql);
		if (mysqli_num_rows($result) > 0) {
			// handle every row
			while($row = mysqli_fetch_assoc($result)) {
				// check overlapping at 10 minutes interval
				for ($i = $start_epoch; $i <= $end_epoch; $i=$i+600) {
					if ($i>($row["start_day"]+$row["start_time"]) && $i<($row["end_day"]+$row["end_time"])) {
						echo '<h3><font color="red">Unfortunately ' . $item . ' has already been booked for the time requested.</font></h3>';
						goto end;
					}
				}
			}				
		}
		
		$sql = "INSERT INTO $tablename (user_id, name, phone, item, start_day, start_time, end_day, end_time, canceled)
			VALUES ('$user_id','$name','$phone', '$item', $start_day, $start_time, $end_day, $end_time, 0)";
		if (mysqli_query($conn, $sql)) {
		    echo "<h3>Booking succeed.</h3>";
		} else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		




function addToGoogleCalendar($title='', $startdate='', $enddate='', $location='', $details='')
{
    $startdate = ($startdate ? $startdate : time());
    $startdate = (is_numeric($startdate) ? $startdate : strtotime($startdate));
    $enddate = ($enddate ? $enddate : $startdate + 3600);
    $enddate = (is_numeric($enddate) ? $enddate : strtotime($enddate));   
    $google_url = "http://www.google.com/calendar/event";
    $action = "?action=TEMPLATE";
    $title = ( $title ? ("&text=" . urlencode($title)) : "") ;
    $dates = "&dates=" . getIcalDate($startdate) . "Z/" . getIcalDate($enddate) . "Z";
    $location = ( $location ? ("&location=" . urlencode($location)) : "") ;
    $details = ( $details ? ("&details=" . urlencode($details)) : "") ;
    $out = $google_url . $action . $title . $dates . $location . $details;
    return $out;
}

function getIcalDate($time, $incl_time = true)
{
    return $incl_time ? date('Ymd\THis', $time) : date('Ymd', $time);
	//header("Location: welcome.php");
}
// add event to google calendar

echo '<a href="' . addToGoogleCalendar($item, $startdatetime, $enddatetime, $name, $phone) . '">Synced Your Booking With Android Calendar</a><br/>';

		end:
		mysqli_close($conn);
	}
?>

<a href="welcome.php"><p>Back to the booking calendar</p></a>

</body>

</html>
