<?php
ob_start();
	include('database.php');
	session_start();
?>
<?php
	if(isset($_POST['form_data'])){
		  $name= mysqli_real_escape_string($con ,$_POST['name']);
		  $email= mysqli_real_escape_string($con ,$_POST['email']);
		  $phone= mysqli_real_escape_string($con ,$_POST['phone']);
		  $age= mysqli_real_escape_string($con ,$_POST['age']);
		  $address= mysqli_real_escape_string($con ,$_POST['address']);
		  $password=  mysqli_real_escape_string($con ,$_POST['password']);
		  $pincode= mysqli_real_escape_string($con ,$_POST['pincode']);
		  $password = md5($password);
		  $insert="insert into add_data set name='$name', email='$email', phone='$phone', age='$age', address='$address', password='$password', pincode='$pincode' ";
			$query=mysqli_query($con, $insert);
			if($query){
				echo"<script>alert('Data Has Been Inserted.')</script>";
				header('Location:index.php');
			}
		}
		ob_end_flush();
?>