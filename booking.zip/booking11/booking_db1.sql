-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2020 at 09:52 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booking_db1`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_data`
--

CREATE TABLE `add_data` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `pincode` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_data`
--

INSERT INTO `add_data` (`id`, `name`, `email`, `phone`, `age`, `address`, `password`, `pincode`) VALUES
(1, 'riaz', 'looklikeriaz@gmail.com', '9758564426', '23', 'Village-Habibpur, Post-Raisi, Distt-Haridwar, (U.K', 'riaz.786', '999995'),
(2, 'Riaz Alam', 'riaz@gmail.com', '9758564426', '23', 'Near  raisi chorhya, raisi', 'qwerty.123', '247671'),
(3, 'Riaz Alam', 'admin@gmail.com', '9758564426', '45', 'Near  raisi chorhya, raisi', 'md5(riazalam)', '247671'),
(4, 'Riaz Alam', 'jony@gmail.con', '9758564426', '35', 'Near  raisi chorhya, raisi', 'riaz', '247671'),
(5, 'MOHD IRSHAD', 'mohdirshad5795@gmail.com', '9758564426', '56', 'Jawalapur, Haridwar', 'password', '249407'),
(6, 'MOHD IRSHAD', 'mohdirshad5795@gmail.com', '9758564426', '34', 'Jawalapur, Haridwar', '', '249407'),
(7, 'Riaz Alam', 'look@gmail.com', '9758564426', '21', 'Near  raisi chorhya, raisi', '22957f76b6dff06fceb58e6c57023ca6', '247671'),
(8, 'admin', 'admin@gmail.com', '9876543210', '23', 'Jawalapur, Haridwar', 'e6e061838856bf47e1de730719fb2609', '249407');

-- --------------------------------------------------------

--
-- Table structure for table `bookingcalendar`
--

CREATE TABLE `bookingcalendar` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `item` varchar(20) NOT NULL,
  `start_day` int(11) DEFAULT NULL,
  `end_day` int(11) DEFAULT NULL,
  `start_time` int(11) DEFAULT NULL,
  `end_time` int(11) DEFAULT NULL,
  `canceled` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookingcalendar`
--

INSERT INTO `bookingcalendar` (`id`, `user_id`, `name`, `phone`, `item`, `start_day`, `end_day`, `start_time`, `end_time`, `canceled`) VALUES
(1, 0, 'Riaz Alam', '09758564426', 'Meeting room', 1589839200, 1589839200, 0, 84600, 1),
(2, 0, 'Riaz Alam_1', '9758564423', 'Meeting room', 1589925600, 1589925600, 21600, 27000, 0),
(3, 8, 'Riaz Alam', '09758564426', 'Meeting room', 1589839200, 1589839200, 0, 84600, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_data`
--
ALTER TABLE `add_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookingcalendar`
--
ALTER TABLE `bookingcalendar`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_data`
--
ALTER TABLE `add_data`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `bookingcalendar`
--
ALTER TABLE `bookingcalendar`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
