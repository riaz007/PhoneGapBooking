<?php
ob_start();
	include('database.php');
	session_start();
?>
<?php
	if(isset($_POST['submit'])){
		$email= mysqli_real_escape_string($con , $_POST['email']) ;
		$password= mysqli_real_escape_string($con ,$_POST['password']) ;
		$password = md5($password);
		$query = "select id, name, phone from add_data where email='$email' and password='$password' ";
		$run_query = mysqli_query($con, $query);
		$found_num_rows = mysqli_num_rows($run_query);
		while($rows= mysqli_fetch_array($run_query)){
		$id = $rows['id'];
		$name = $rows['name'];
		$phone = $rows['phone'];
		}
		if($found_num_rows==1){
			$_SESSION['email']= $email;
			$_SESSION['id']= $id;
			$_SESSION['name']= $name;
			$_SESSION['phone']= $phone;
			header("Location:welcome.php");
		}
		else{
			header('Location:index.php?invalid=Your Username or Password is incorrect. Please try again');
		}	
	}
	ob_end_flush();
?>
