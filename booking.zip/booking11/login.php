<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Website</title>
</head>

<body>
<div style="background-color:#CCCCCC; width:100%;">
<div style="padding-left:40%; padding-top:100px; padding-bottom:100px;">
<form action="login_data.php" method="post" enctype="multipart/submit" onsubmit="return validate();">

<table border='1' maxlength="50" style="width:260px; background-image:url(truform-banner1.jpg)">
<tr>
<td><h1>Log IN</h1></td>
</tr>
<tr>
<td style="width:50%">
<b>Email</b><br />
<input type="text" id="email" name="email" maxlength="50" style="width:260px"/>
<span style="color:red" id="emailerr"></span><br/><br/>
</td>
</tr>
<tr>
<td style="width:50%">
<b>Password</b><br />
<input type="password" id="password" name="password" maxlength="50" style="width:260px"/></br></br>
</td>
</tr>
<td>
</br><input type="submit" name="submit" value="Login" maxlength="50" style="width:260px"/></br></br>
</td>
</tr>
</table>
</form>
</div>

<script type="text/javascript" src="val2.js"></script> 
</div>
</body>
</html>
