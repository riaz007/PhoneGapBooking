<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Website</title>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
  text-align: left;
}
</style>
</head>

<body>
<?php
	ob_start();
	include('database.php');
	session_start();
?>
			<fieldset>
			<legend><h2>Register Users</h2></legend>
							 
<table style="width:100%">
  <tr>
    <th>ID</th>
    <th>Name</th> 
    <th>Email</th>
	<th>Phone</th>
	<th>Age</th>
	<th>Address</th>
	<th>Picode</th>
  </tr>
   <?php
	$sel_query="select * from add_data ";
	$run_query = mysqli_query($con , $sel_query );
	while($rows= mysqli_fetch_array($run_query)){
		$id = $rows['id'];
		$name = $rows['name'];
		$email = $rows['email'];
		$phone = $rows['phone'];
		$age = $rows['age'];
		$address = $rows['address'];
		$pincode = $rows['pincode'];
		
?>
  <tr>
    <td><?php echo $id ;?></td>
    <td><?php echo $name ?></td>
    <td><?php echo $email ?></td>
	<td><?php echo $phone ?></td>
	<td><?php echo $age ?></td>
	<td><?php echo $address ?></td>
	<td><?php echo $pincode ?></td>
  </tr>
</table>
</fieldset>

<?php 
}
ob_end_flush(); ?>

</body>
</html>
