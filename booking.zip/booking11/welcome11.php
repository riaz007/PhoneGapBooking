<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Website</title>
</head>

<body>
<?php
ob_start();
	include('database.php');
	session_start();
?>
<div style="background-color:#CCCCCC; width:100%;">
<div style="padding-left:40%; padding-top:100px; padding-bottom:100px;">
<table border='1' maxlength="50" style="width:260px; background-image:url(truform-banner1.jpg)">
<tr>
<td><marquee><h1>Thankyou</h1></marquee></td>
</tr>
<tr>
<td style="width:50%">
<a href="view.php"><h2>Database Entry</h2></a>
</td>
</tr>
<tr>
<td style="width:50%">
<a href="logout.php"><h2>Log Out</h2></a>
</td>
</tr>
</table>
</div> 
</div>

<?php 
ob_end_flush(); ?>
</body>
</html>
