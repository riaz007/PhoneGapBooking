<html>
<body>
<?php
ob_start();
	session_start();
	unset($_SESSION); 
	session_destroy();
	header('Location:index.php?logout=You are logout successfully');
ob_end_flush();
?>
 <script type = "text/javascript" >
    alert("You Have Successfully logout");
    history.pushState(null, null, 'logout.jsp');
    window.addEventListener('popstate', function(event) {
    history.pushState(null, null, 'logout.jsp');
    });
function closeMyWin()
{
	window.close();
}
</script>
</body>
</html>