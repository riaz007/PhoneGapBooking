

<?php

$con=mysqli_connect("localhost","root","","booking_db1");

if(mysqli_connect_errno())
{
	echo"Failed to connect to mysql". mysqli_connect_error();
}

?>